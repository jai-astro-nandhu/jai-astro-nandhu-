JOTHIDAM V36 FINAL COMPLETE
===========================

1. Extract this ZIP.
2. Double-click start_windows.bat.
3. Keep the black window open while using the website.
4. The launcher checks Python + Swiss Ephemeris and runs a self-test.
5. The browser opens automatically.

Validation case:
12/01/1998 (12 January 1998)
7:30 PM
Pollachi, Tamil Nadu, India
Expected Lagna: கடகம்

Features: South Indian Rasi, Navamsa, Nakshatra/Pada, Vimshottari Dasha-Bhukti, 12 Bhavas, integrated Tamil Palangal, global location search, DD/MM/YYYY display, print/PDF, Jai Astro Nandhu visiting card.
