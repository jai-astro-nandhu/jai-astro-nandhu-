@echo off
setlocal
cd /d "%~dp0"
set "PY="
where py >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if not defined PY set "PY=python"

echo Installing Swiss Ephemeris Python engine...
%PY% -m pip install --disable-pip-version-check pysweph
if errorlevel 1 (
  echo.
  echo Installation failed. Connect the laptop to the internet and try again.
  pause
  exit /b 1
)
echo.
echo Swiss Ephemeris installation completed.
pause
