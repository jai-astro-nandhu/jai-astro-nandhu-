import os
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def find_python():
    if os.name == 'nt':
        candidates = [['py','-3'], ['python']]
    else:
        candidates = [[sys.executable]]
    for cmd in candidates:
        try:
            r = subprocess.run(cmd + ['-c','import sys; print(sys.version)'], capture_output=True, text=True, timeout=8)
            if r.returncode == 0:
                return cmd
        except Exception:
            pass
    return None

def main():
    py = find_python()
    if not py:
        print('Python 3 is not available.')
        input('Press Enter to close...')
        return 1

    os.chdir(ROOT)
    try:
        import server
        port = server.find_free_port()
    except Exception as e:
        print('[ERROR] Server module could not load:')
        print(repr(e))
        input('Press Enter to close...')
        return 1

    env = os.environ.copy()
    env['JOTHIDAM_PORT'] = str(port)
    log_path = ROOT / 'server_error.log'
    print(f'Starting Jothidam server at http://127.0.0.1:{port}/')
    print('Server log:', log_path)
    with open(log_path, 'w', encoding='utf-8') as log:
        proc = subprocess.Popen(
            py + [str(ROOT / 'server.py')], cwd=str(ROOT), env=env,
            stdout=log, stderr=subprocess.STDOUT
        )

    time.sleep(1.5)
    if proc.poll() is not None:
        print('[ERROR] Server stopped immediately.')
        try:
            print(log_path.read_text(encoding='utf-8')[-4000:])
        except Exception:
            pass
        input('Press Enter to close...')
        return proc.returncode or 1

    url = f'http://127.0.0.1:{port}/'
    print('Opening:', url)
    try:
        webbrowser.open(url, new=2)
    except Exception as e:
        print('Browser could not be opened automatically:', repr(e))
        print('Open this address manually:', url)
    print('Keep this black window open while using the website.')
    print('Close it only after you finish.')
    try:
        rc = proc.wait()
    except KeyboardInterrupt:
        proc.terminate()
        rc = 0
    return rc

if __name__ == '__main__':
    raise SystemExit(main())
