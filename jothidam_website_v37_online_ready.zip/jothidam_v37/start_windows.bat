@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
chcp 65001 >nul

echo ==========================================
echo     JOTHIDAM - V36 FINAL COMPLETE
echo ==========================================
echo.

echo [1/4] Finding real Python installation...
set "PYEXE="
where py >nul 2>&1
if not errorlevel 1 (
  for /f "delims=" %%P in ('py -3 -c "import sys; print(sys.executable)" 2^>nul') do if not defined PYEXE set "PYEXE=%%P"
)
if not defined PYEXE (
  for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE (
    echo %%P | findstr /I /C:"WindowsApps" >nul
    if errorlevel 1 set "PYEXE=%%P"
  )
)
if not defined PYEXE if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set "PYEXE=%LocalAppData%\Programs\Python\Python313\python.exe"
if not defined PYEXE if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYEXE=%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PYEXE (
  echo [ERROR] Real Python 3 installation not found.
  pause
  exit /b 1
)
echo [OK] Python: %PYEXE%
"%PYEXE%" --version
if errorlevel 1 goto py_error

echo.
echo [2/4] Checking Swiss Ephemeris...
"%PYEXE%" -c "import swisseph as swe; print('[OK] Swiss Ephemeris:', getattr(swe,'version','unknown'))" >nul 2>&1
if errorlevel 1 (
  echo [INFO] Installing pysweph...
  "%PYEXE%" -m pip install --disable-pip-version-check pysweph
  if errorlevel 1 (
    echo [ERROR] pysweph installation failed.
    pause
    exit /b 2
  )
)
echo [OK] Swiss Ephemeris ready.

echo.
echo [3/4] Running calculation self-test...
"%PYEXE%" -c "import sys; sys.path.insert(0,'.'); import server; r=server.calculate({'name':'Self Test','date':'1998-01-12','time':'19:30:00','place':'Pollachi, Tamil Nadu, India','place_name':'Pollachi, Tamil Nadu, India','lat':10.6586,'lon':77.0080,'timezone':'Asia/Kolkata'}); print('[OK] Test result: '+r['lagna']['sign']+' Lagna; '+r['moon']['__class__.__name__'] if False else '[OK] Test result: '+r['lagna']['sign']+' Lagna')"
if errorlevel 1 (
  echo [ERROR] Calculation self-test failed.
  echo See the message above.
  pause
  exit /b 3
)

echo.
echo [4/4] Starting Jothidam server...
"%PYEXE%" launcher.py
set "RC=%errorlevel%"
echo.
echo ==========================================
echo Server stopped. Exit code: %RC%
echo ==========================================
pause
exit /b %RC%

:py_error
echo [ERROR] Python was found but could not run.
pause
exit /b 1
